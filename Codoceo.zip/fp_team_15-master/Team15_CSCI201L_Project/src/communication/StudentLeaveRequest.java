package communication;

public class StudentLeaveRequest extends Update{

	private static final long serialVersionUID = 9085812738641753513L;

	public StudentLeaveRequest() {
	}
}
