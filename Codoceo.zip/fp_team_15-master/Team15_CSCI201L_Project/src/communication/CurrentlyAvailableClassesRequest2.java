package communication;


public class CurrentlyAvailableClassesRequest2 extends Update{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6071404327302461300L;

	public CurrentlyAvailableClassesRequest2() {
		
	}
}
