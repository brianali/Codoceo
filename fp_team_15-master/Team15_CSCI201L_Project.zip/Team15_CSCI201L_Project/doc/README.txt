Final Project Group 15

Group Members:
- Briana Liang
- Phillip Nazarian
- Prerana Reddy
- Nikhil Sinha
- Zhaoqi Zhu

To execute the program:
- Server: server.ServerGUI
- Client: client.LoginGUI

Now the project is completed and all the major features described in the documentation have been implemented the way they should be.  
However, some bugs/issues include:  
1. When the instructor leaves the classroom the student's view does not respond correctly. The communication is well written so the fix should be just within a few lines.  
2. The GUI may not look as nice as in the documentation, although its functionality is complete. This will also be fixed very soon.
3. Further tests required for duplicate logging in and multiple students listening to one class.
4. Further tests required to ensure that guests do not have inappropriate privileges.



