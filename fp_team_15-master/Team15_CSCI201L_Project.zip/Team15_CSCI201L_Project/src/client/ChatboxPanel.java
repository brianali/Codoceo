package client;

import java.awt.BorderLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EtchedBorder;

import shared.Chatbox;
import shared.ChatboxUpdate;
import shared.Classroom;
import shared.User;

public class ChatboxPanel extends ClassroomFeaturePanel<Chatbox> {

	private static final long serialVersionUID = 4510576683938306987L;
	private JTabbedPane chatTabs;
	private JTextField messageField;
	private JCheckBox sendMessageBox;
	private User recipient;
	JTextArea messageArea;
	JComboBox<String> cb;
	String msg = null;
	//
	// Member Variables:
	//
	
	@Override
	public boolean isTab() { return false; }
	
	//
	// Methods:
	//
	
	public ChatboxPanel(Chatbox chatbox, Classroom classroom, User user) {
		
		super(chatbox, classroom, user);
		createGUI();
		recipient = null;
	}
	
	public void createGUI() {
		
		setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
		
		if(amInstructor()){
			cb = new JComboBox<String>();
			add(cb, BorderLayout.NORTH);
			cb.addItem("Group");
			System.out.println(classroom==null?"null":"not null");
			System.out.println(classroom.getStudents()==null?"null":"not null");
			System.out.println(classroom.getStudents().size());
			for(User student : classroom.getStudents()){
				cb.addItem(student.getDisplayName());
			}
			cb.addItemListener(new ItemListener(){
				public void itemStateChanged(ItemEvent event) {
					if (event.getStateChange() == ItemEvent.SELECTED) {
				          String username = (String)event.getItem();
				          if(username=="Group"){
				        	  recipient = null;
				          }
				          else{
				        	  recipient = classroom.getUserByUsername(username);
				          }
				       }
				}
			});
		}
		else{
			JLabel label = new JLabel(amInstructor() ? "I am an instructor chatbox!" : "I am a student chatbox!");
			add(label, BorderLayout.NORTH);
		}
		JPanel southPanel = new JPanel();
		southPanel.setLayout(new BoxLayout(southPanel, BoxLayout.Y_AXIS));
		add(southPanel, BorderLayout.SOUTH);
		
		chatTabs = new JTabbedPane();
		JPanel groupTab = new JPanel();
		messageArea = new JTextArea(15, 30);
		messageArea.setEditable(false);
		groupTab.add(messageArea);
		if (!amInstructor()){
			chatTabs.addTab("Group",groupTab);
			JPanel instructorTab = new JPanel();
			chatTabs.addTab("Instructor", instructorTab);
			sendMessageBox = new JCheckBox("Send to instructor");
			southPanel.add(sendMessageBox);
			sendMessageBox.addItemListener(new ItemListener() {
			      public void itemStateChanged(ItemEvent e) {
			        if(sendMessageBox.isSelected())
			        	recipient = classroom.getInstructor();
			        else
			        	recipient = null;
			      }
			    });

			add(chatTabs, BorderLayout.CENTER);
		}
		else{
			groupTab.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.LOWERED), new BevelBorder(BevelBorder.RAISED)));
			add(groupTab, BorderLayout.CENTER);
		}
		
		messageField = new JTextField("Enter a message");
		messageField.addMouseListener(new MouseListener(){
			public void mouseClicked(MouseEvent arg0) {
				if(messageField.getText().equals("Enter a message"))
					messageField.setText("");
			}
			public void mouseEntered(MouseEvent arg0) {}
			public void mouseExited(MouseEvent arg0) {}
			public void mousePressed(MouseEvent arg0) {}
			public void mouseReleased(MouseEvent arg0) {}
		});
		messageField.addKeyListener(new KeyListener(){
			public void keyPressed(KeyEvent ke) {
				if(ke.getKeyCode()==KeyEvent.VK_ENTER){
					messageArea.requestFocusInWindow();
					msg = messageField.getText();
					flushMessage();
				}
			}
			public void keyReleased(KeyEvent arg0) {}
			public void keyTyped(KeyEvent arg0) {}
		});
		southPanel.add(messageField);
	}
	
	public void flushMessage(){
		feature.sendUpdate(new ChatboxUpdate(msg, user, recipient));
		messageField.setText("Enter a message");
	}
	
	public void addMessage(int to, int from, String message){
//		if(user.getID()==to||to==-1)
		System.out.println(to);
		System.out.println(from);
		messageArea.append(classroom.getUserByID(from).getDisplayName()+ ": " + message +"\n");
	}
	
	public void addUserToInstructorCB(User u){
		cb.addItem(u.getDisplayName());
	}
	
}
