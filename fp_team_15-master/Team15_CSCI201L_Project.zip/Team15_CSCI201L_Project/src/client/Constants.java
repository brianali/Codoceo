package client;

import java.awt.Font;

abstract public class Constants {

	public final static int standardFontSize = 16;
	public final static Font standardFont = new Font("SansSerif", Font.PLAIN, standardFontSize);
	
}
