package listeners;

import java.awt.Color;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JTextField;
public class TextFocusListener implements FocusListener{

	private String defaultText;
	private JTextField thisTextField;
	
	public TextFocusListener(String defaultText, JTextField thisTextField) {
		this.defaultText = defaultText;
		this.thisTextField = thisTextField;
		thisTextField.setText(defaultText);
		thisTextField.setForeground(Color.gray);
	}

	@Override
    public void focusGained(FocusEvent fe)
    {
		thisTextField.setForeground(Color.black);
        thisTextField.setText("");
	    
    }

    @Override
    public void focusLost(FocusEvent fe)
    {
    	if (thisTextField.getText().equals("")){
    		thisTextField.setForeground(Color.gray);
	    	thisTextField.setText(defaultText);
    	}
    
    }
}
