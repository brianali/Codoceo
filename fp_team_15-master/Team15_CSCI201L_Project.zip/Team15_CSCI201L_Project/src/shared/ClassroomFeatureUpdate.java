package shared;

import communication.Update;

public class ClassroomFeatureUpdate extends Update{

	private static final long serialVersionUID = 899979907702999374L;
}
