package communication;

public class StartClassResponse extends Update {

	private static final long serialVersionUID = -6896895994696229680L;

}
