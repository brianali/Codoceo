package communication;

public class InstructorLeftUpdate extends Update{

	private static final long serialVersionUID = -1033647335384174293L;

	public InstructorLeftUpdate() {
		
	}
}
